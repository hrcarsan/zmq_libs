#!/bin/bash

apt-get install -y libtool pkg-config build-essential autoconf automake uuid-dev
cd libsodium/
./autogen.sh
./configure && make check
make install
ldconfig
cd ..
cd zeromq-4.2.0
./autogen.sh
./configure && make check
make install
ldconfig
cd ..
cd czmq
./autogen.sh
./configure
make -j 8
make install
cd ..
cd php-zmq/
./configure --with-czmq
make
make test
make install
printf "\nextension=zmq.so" >> /etc/php5/fpm/php.ini
printf "\nextension=zmq.so" >> /etc/php5/cli/php.ini
printf "\nextension=zmq.so" >> /etc/php5/apache2/php.ini
